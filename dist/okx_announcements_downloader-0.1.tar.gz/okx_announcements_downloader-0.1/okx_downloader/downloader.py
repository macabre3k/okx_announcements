import os
import requests
from bs4 import BeautifulSoup
from datetime import datetime
from .utils import validate_date_range, sanitize_filename, log_message

def fetch_announcements(start_date: str, end_date: str, folder: str):
    validate_date_range(start_date, end_date)
    start_date = datetime.strptime(start_date, '%Y-%m-%d')
    end_date = datetime.strptime(end_date, '%Y-%m-%d')


    base_url = "https://www.okx.com/help/category/announcements"

    os.makedirs(folder, exist_ok=True)

    response = requests.get(base_url)
    if response.status_code != 200:
        log_message(f"Не удалось загрузить данные с {base_url}. Код ошибки: {response.status_code}")
        return

    soup = BeautifulSoup(response.text, 'html.parser')
    announcements = soup.find_all('a', href=True)

    for announcement in announcements:
        link = announcement['href']
        title = announcement.get_text(strip=True)

        if not link.startswith('/help'): 
            continue

        full_url = f"https://www.okx.com{link}"


        announcement_response = requests.get(full_url)
        if announcement_response.status_code != 200:
            log_message(f"Не удалось загрузить страницу объявления: {full_url}. Код ошибки: {announcement_response.status_code}")
            continue

        filename = sanitize_filename(f"{title}.html")
        file_path = os.path.join(folder, filename)
        with open(file_path, 'w', encoding='utf-8') as file:
            file.write(announcement_response.text)

        log_message(f"Сохранено объявление: {title} в {file_path}")
