import unittest
from datetime import datetime
from okx_downloader.utils import validate_date_range, sanitize_filename, log_message
from okx_downloader.downloader import fetch_announcements
import os
import sys

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '../..')))
class TestUtils(unittest.TestCase):
    def test_validate_date_range_valid(self):
        try:
            validate_date_range("2023-01-01", "2023-12-31")
        except ValueError:
            self.fail("validate_date_range()")

    def test_validate_date_range_invalid(self):
        with self.assertRaises(ValueError):
            validate_date_range("2023-12-31", "2023-01-01")

    def test_sanitize_filename(self):
        result = sanitize_filename("Test / File \\ Name")
        self.assertEqual(result, "Test__File__Name")

    def test_log_message(self):
        try:
            log_message("Test log message.")
        except Exception as e:
            self.fail(f"log_message() вызвал ошибку: {e}")

class TestDownloader(unittest.TestCase):
    def setUp(self):
        self.test_folder = "./test_announcements"
        os.makedirs(self.test_folder, exist_ok=True)

    def tearDown(self):
        for file in os.listdir(self.test_folder):
            os.remove(os.path.join(self.test_folder, file))
        os.rmdir(self.test_folder)

    def test_fetch_announcements(self):
        try:
            fetch_announcements(
                start_date="2023-01-01",
                end_date="2023-01-31",
                folder=self.test_folder
            )
            self.assertTrue(len(os.listdir(self.test_folder)) > 0, "Должны быть сохраненные файлы.")
        except Exception as e:
            self.fail(f"fetch_announcements() вызвал ошибку: {e}")

if __name__ == "__main__":
    unittest.main()
